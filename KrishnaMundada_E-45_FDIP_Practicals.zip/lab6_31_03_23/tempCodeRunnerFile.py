temp=sorted(temp)
        img_new[i,j]=temp[4]