<h2>Introduction to Python</h2>
<hr>
<h4>Aim</h4>
<ul>
<li><h5>To learn about various concepts of python, operators, datatypes, list, dictionary, tokens, conditional statements, functions and arrays</h5></li>
<li><h5>To get familiar with Open CV library and Pycharm ide</h5></li>
<hr>

<h4>Lab Description</h4>
<h5>Installation</h5>
